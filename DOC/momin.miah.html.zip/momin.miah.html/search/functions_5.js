var searchData=
[
  ['jugador_104',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a416451520449462f311e4bc397dd4b31',1,'Jugador::Jugador(string nom)']]]
];
