var searchData=
[
  ['pasar_5fjugadores_50',['pasar_jugadores',['../class_torneo.html#a3e890b22a3143d7837beece031cecec8',1,'Torneo']]],
  ['program_2ecc_51',['program.cc',['../program_8cc.html',1,'']]],
  ['punts_52',['punts',['../class_categorias.html#afb06da25ddccebdd524d7974cb24ca84',1,'Categorias']]]
];
