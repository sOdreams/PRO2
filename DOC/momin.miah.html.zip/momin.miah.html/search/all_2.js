var searchData=
[
  ['cat_5fnom_9',['cat_nom',['../class_categorias.html#a6bf153a1cd0bd86fc2e35c0aaad9926b',1,'Categorias']]],
  ['categorias_10',['Categorias',['../class_categorias.html',1,'Categorias'],['../class_categorias.html#a9c8353e5665cf7c4f64d7165776518ac',1,'Categorias::Categorias()'],['../class_categorias.html#af011be008939119da21b41749ad66f91',1,'Categorias::Categorias(int c, int k)']]],
  ['categorias_2ehh_11',['Categorias.hh',['../_categorias_8hh.html',1,'']]],
  ['cjt_5fjugadores_12',['Cjt_Jugadores',['../class_cjt___jugadores.html',1,'Cjt_Jugadores'],['../class_cjt___jugadores.html#a2e7a3bb35253088c8b66d6cfbc89742f',1,'Cjt_Jugadores::Cjt_Jugadores()']]],
  ['cjt_5fjugadores_2ehh_13',['Cjt_Jugadores.hh',['../_cjt___jugadores_8hh.html',1,'']]],
  ['cjt_5ftorneos_14',['Cjt_Torneos',['../class_cjt___torneos.html',1,'Cjt_Torneos'],['../class_cjt___torneos.html#a3da93ce7730f6472ab958496f4af3ec1',1,'Cjt_Torneos::Cjt_Torneos()']]],
  ['cjt_5ftorneos_2ehh_15',['Cjt_Torneos.hh',['../_cjt___torneos_8hh.html',1,'']]],
  ['consul_5fcat_16',['consul_cat',['../class_torneo.html#a655184ad639782f718aa2bbcf84da89b',1,'Torneo']]],
  ['consul_5fid_17',['consul_id',['../class_jugador.html#a19fa227e17f3f76e0fb64f7e3ad41713',1,'Jugador']]],
  ['consul_5fid_5ftorneo_18',['consul_id_torneo',['../class_torneo.html#a1786fa335e82c968a1b7bdc64a9abe50',1,'Torneo']]],
  ['consul_5fpuntos_19',['consul_puntos',['../class_jugador.html#a20937c2060487d7d2072574f4c1c7a1d',1,'Jugador']]],
  ['consultar_5fjugador_20',['consultar_jugador',['../class_cjt___jugadores.html#aa2811c7bb778f753bda31c3fba787a6c',1,'Cjt_Jugadores']]],
  ['consultar_5fmida_21',['consultar_mida',['../class_cjt___jugadores.html#a02fe55b5dc0afca9dc39784966cd990a',1,'Cjt_Jugadores']]],
  ['copiar_5ftorneo_22',['copiar_torneo',['../class_cjt___torneos.html#ab6f99a5b83da7a2175df32de211a5127',1,'Cjt_Torneos']]],
  ['cuadro_5femparejamiento_23',['cuadro_emparejamiento',['../class_cjt___torneos.html#aa76d443857c43b86ccd01eb3e418b07a',1,'Cjt_Torneos']]],
  ['cuadro_5finicial_24',['cuadro_inicial',['../class_torneo.html#a9a31b565e28326d9287d854815018bfb',1,'Torneo']]]
];
