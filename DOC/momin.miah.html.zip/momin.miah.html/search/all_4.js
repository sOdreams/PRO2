var searchData=
[
  ['iniciar_5ftorneo_36',['iniciar_torneo',['../class_torneo.html#a65f5d9c94f85c136f2d096a172a82abe',1,'Torneo']]],
  ['iniciar_5ftorneos_37',['iniciar_torneos',['../class_cjt___torneos.html#a6a4e67e2ef3c90cac6e0ed32db72f9b8',1,'Cjt_Torneos']]]
];
