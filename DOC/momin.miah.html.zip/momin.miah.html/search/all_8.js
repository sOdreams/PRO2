var searchData=
[
  ['nuevo_5fjugador_48',['nuevo_jugador',['../class_cjt___jugadores.html#afb1c55675284a252eb308a0be45bb2ca',1,'Cjt_Jugadores']]],
  ['nuevo_5ftorneo_49',['nuevo_torneo',['../class_cjt___torneos.html#a3bbba3261e27aa92487682c278f2d4ad',1,'Cjt_Torneos']]]
];
