var searchData=
[
  ['pasar_5fjugadores_115',['pasar_jugadores',['../class_torneo.html#a3e890b22a3143d7837beece031cecec8',1,'Torneo']]],
  ['punts_116',['punts',['../class_categorias.html#afb06da25ddccebdd524d7974cb24ca84',1,'Categorias']]]
];
