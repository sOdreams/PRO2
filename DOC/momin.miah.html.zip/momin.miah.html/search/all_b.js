var searchData=
[
  ['torneo_54',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a203e2b3ea4ed8d6a9dc332cdf960e1c9',1,'Torneo::Torneo(string nom, int cat)']]],
  ['torneo_2ehh_55',['Torneo.hh',['../_torneo_8hh.html',1,'']]]
];
