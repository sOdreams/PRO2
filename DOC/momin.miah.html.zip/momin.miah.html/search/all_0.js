var searchData=
[
  ['acaba_5ftorneo_0',['acaba_torneo',['../class_torneo.html#a3aac9173eb2f402b1f08e39c9cb8e70b',1,'Torneo']]],
  ['actualizar_1',['actualizar',['../class_jugador.html#acd907617a694032fee760ae0853041de',1,'Jugador']]],
  ['actualizar_5fedicion_2',['actualizar_edicion',['../class_torneo.html#a53eccfb2e90dba57cbedc166bacf7473',1,'Torneo']]],
  ['actualizar_5femparejamiento_3',['actualizar_emparejamiento',['../class_torneo.html#a1c0be1c06c93485645a0cd09dcbf5f68',1,'Torneo']]],
  ['actualizar_5fpuntos_5ftorneo_4',['actualizar_puntos_torneo',['../class_torneo.html#ac1a6ccb4f64f2aadd269775a3549f5ef',1,'Torneo']]],
  ['analizar_5fresultados_5',['analizar_resultados',['../class_torneo.html#a30105869851fc5c66c391cb0493b9776',1,'Torneo']]]
];
